=============================================
   LOST AND FOUND SYSTEM
   Java NetBeans + MySQL (2 User Roles)
=============================================

HOW IT WORKS:
  REPORTER - can CREATE, READ, UPDATE, DELETE items
           - can approve claims (set status to "Claimed")
  CLAIMER  - can BROWSE and SEARCH items
           - can CLAIM unclaimed items (sets status to "Claim Pending")
           - Reporter then approves by updating status to "Claimed"

INTERACTION FLOW:
  1. Reporter logs in -> reports a found item (status: Unclaimed)
  2. Claimer logs in -> sees the item -> clicks CLAIM
  3. Status changes to "Claim Pending" with claimer's name recorded
  4. Reporter logs in -> sees the pending claim -> Updates status to "Claimed"

FILES (6 Java files):
  DBConnection.java      - MySQL connection
  Main.java              - Entry point (opens Login)
  LoginForm.java         - Login screen
  RegisterForm.java      - Register screen (choose Reporter/Claimer)
  ReporterDashboard.java - Full CRUD for reporters
  ClaimerDashboard.java  - Browse + Claim for claimers

SETUP:
  1. Start MySQL (XAMPP -> Start MySQL)
  2. Run database.sql in phpMyAdmin
  3. NetBeans: New Project -> Java with Ant -> Java Application
  4. Copy all .java files into Source Packages
  5. Right-click Libraries -> Add Library -> MySQL JDBC Driver
  6. Run (Main Class: Main)

DEFAULT ACCOUNTS:
  Reporter: reporter1 / pass123
  Claimer:  claimer1  / pass123
=============================================
